SurvivalGame インベントリ画像パッチ

1. プロジェクト内の現在の main.ts を、同梱の main.ts に置き換えてください。
2. 同梱の public/resources/ を、プロジェクトの public/ の中へコピーしてください。
3. 開発サーバーを再起動してください。

resources 内の画像はインベントリ・ホットバー用に256pxへ軽量化しています。
